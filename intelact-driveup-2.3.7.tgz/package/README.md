## Description
This is a private property of the Intelact company and is allowed to be used only within Intelact Solutions products.

## Installation

```bash
$ npm install
```

## Build

```bash
$ npm run build
```

## Publish

```bash
$ npm login
$ npm publish
```

## Support

Any change in the this library should result in a upgrade of the semantic version. The versioning strategy is defined by the CTO.

## Stay in touch

- Author - [Admir Serifi](https://twitter.com/admirsherifi)
- Owner - [Intelact Solutions Ltd](https://intelact.co)

## License

Intelact Driveup Common is prvate common libraray and is no licensed.
