export declare class Credit {
    id: number;
    description: string;
    amount: number;
    createdBy: any;
    createdOn: Date;
    constructor(props?: Partial<Credit>);
}
