export declare class SettingValueDto {
    value: string;
}
