import { PreferenceScope } from "@driveup/shared";
export declare class Setting {
    id: number;
    scope: PreferenceScope;
    name: string;
    value: string;
    title: string;
    description: string;
    constructor(props?: Partial<Setting>);
}
