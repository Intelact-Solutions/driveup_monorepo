import { Holiday, Link, Role, StatusType } from "@driveup/shared";
import { Training } from "../training/training.model";
import { Company } from "../company/company.model";
import { Course } from "../course/course.model";
import { WorkdayDefinition } from "../calendar/working";
import { User } from "../user/user.model";
export declare class Instructor {
    id: number;
    name: string;
    image: string;
    imageUrl: string;
    phone: string;
    status: StatusType;
    role: Role;
    /**
     * Stringified json object
     */
    holidays: Holiday[];
    /**
     * Stringified json object
     */
    workingHours: WorkdayDefinition[];
    calendarLinks: Link[];
    canReinstate: boolean;
    busy: boolean;
    user: User;
    totalCourses: number;
    totalDrivingTrainings: number;
    startedOn: Date;
    invitedBy: any;
    invitedOn: Date;
    closedBy: any;
    closedOn: Date;
    company: Company;
    courses: Course[];
    drivingTrainings: Training[];
    /************************* finances *************************/
    pendingExpenses: number;
    pendingDrivingPayments: number;
    pendingCoursePayments: number;
    /************************* activity *************************/
    totalAppointments: number;
    totalGeneratedValue: number;
    totalExpenses: number;
    constructor(props?: Partial<Instructor>);
}
