import { Metric } from "../metric/metric.model";
export declare class Currency {
    id: number;
    name: string;
    abbr: string;
    symbol: string;
    chRate: number;
    active: boolean;
    metrics: Metric[];
    constructor(props?: Partial<Currency>);
}
