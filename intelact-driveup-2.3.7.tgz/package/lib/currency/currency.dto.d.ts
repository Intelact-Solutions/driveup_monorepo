export declare class CurrencyCreateDto {
    name: string;
    abbr: string;
    symbol: string;
    chRate: number;
}
export declare class CurrencyUpdateDto {
    name: string;
    abbr: string;
    symbol: string;
    chRate: number;
    active: boolean;
}
export declare class CurrencySearchDto {
    name: string;
    abbr: string;
    symbol: string;
    active: boolean;
}
