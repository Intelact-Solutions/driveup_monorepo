import { StatusType } from "@driveup/shared";
import { DrivingTopic } from "../../driving/lesson/topic";
import { DrivingSessionSkill } from "./session.skill";
export declare class DrivingSessionTopic extends DrivingTopic {
    completedBy: any;
    completedOn: Date;
    sessionSkills: DrivingSessionSkill[];
    drivingTopicId: number;
    /************************* exam *************************/
    status: StatusType;
    constructor(props?: Partial<DrivingSessionTopic>);
    getScore(): number;
}
