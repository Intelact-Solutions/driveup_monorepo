import { Note } from "@driveup/shared";
import { Appointment } from "../../calendar/appointment";
import { DrivingExam } from "../../driving/exam/exam.model";
import { Signature } from "../../signature/signature.model";
import { DrivingSessionTopic } from "./session.topic";
export declare class DrivingSession extends Appointment {
    price: number;
    duration: number;
    nextTopic: DrivingSessionTopic;
    note: Note;
    signature: Signature;
    /************************* exam *************************/
    exam: DrivingExam;
    /************************* methods *************************/
    constructor(props?: Partial<DrivingSession>);
}
