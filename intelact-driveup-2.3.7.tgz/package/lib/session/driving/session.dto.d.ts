import { PickupLocation } from "../../geo/pickup.model";
export declare class InstructorDrivingAppointmentCreateDto {
    instructorId: number;
    date: Date;
    isExam: boolean;
    location: PickupLocation;
}
export declare class InstructorDrivingAppointmentUpdateDto {
    date: Date;
    isExam: boolean;
    location: PickupLocation;
    instructorId: number;
}
