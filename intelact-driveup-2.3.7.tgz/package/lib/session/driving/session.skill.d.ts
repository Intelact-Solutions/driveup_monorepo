import { DrivingSkill } from "../../driving/lesson/skill";
export declare class DrivingSessionSkill extends DrivingSkill {
    drivingSkillId: number;
    constructor(props?: Partial<DrivingSessionSkill>);
}
