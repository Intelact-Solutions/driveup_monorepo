export declare class Signature {
    /************************* Definitions *************************/
    id: number;
    description: string;
    date: Date;
    image: string;
    imageUrl: string;
    /************************* methods *************************/
    constructor(props?: Partial<Signature>);
}
