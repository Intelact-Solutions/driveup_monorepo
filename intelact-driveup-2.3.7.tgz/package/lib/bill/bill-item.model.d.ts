import { Training } from "../training/training.model";
import { Instructor } from "../instructor/instructor.model";
export declare class CompanyBillItem {
    id: number;
    createdOn: Date;
    training: Training;
    instructor: Instructor;
    priceNumeric: number;
    vat: number;
    totalPrice: number;
    freeBenefit: boolean;
    outOfPlan: boolean;
    /************************* Main fields shown in the UI *************************/
    /**
     * Driving Training / Course Trianing / Instructor Name / Enterprise Plan: 15 seats
     */
    title: string;
    /**
     * Driving training's category name / Course training's course title
     */
    subtitle: string;
    /**
     * Student name / Number of days subscribed / Used seats
     */
    description: string;
    /**
     * Price and currency abbr (15 CHF)
     *
     * - UI must handle crossing line over the price if freeBenefit is true
     */
    price: string;
    /**
     * For free benefit items
     */
    priceDescription: string;
    /************************* Methods *************************/
    constructor(props?: Partial<CompanyBillItem>);
}
