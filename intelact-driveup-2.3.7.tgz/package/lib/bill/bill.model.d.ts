import { StatusType } from "@driveup/shared";
import { CompanyBillItem } from "./bill-item.model";
export declare class CompanyBill {
    id: number;
    paid: boolean;
    status: StatusType;
    /************************* Date *************************/
    startDate: Date;
    endDate: Date;
    year: number;
    month: number;
    monthLocalized: string;
    /************************* Price *************************/
    subTotalPrice: number;
    totalPrice: number;
    /**
     * Total amount that was reducted from credit
     */
    fromCredit: number;
    /**
     * Total number of trainings that were covered by free benefits
     */
    freeBenefits: number;
    /**
     * Total amount of the trainings that was covered by free benefits
     */
    fromFreeBenefits: number;
    /**
     * Total amount that was reducted from credit or was covered by free benefits
     */
    fromCreditOrFreeBenefits: number;
    taxAmount: number;
    items: CompanyBillItem[];
    /************************* Methods *************************/
    constructor(props?: Partial<CompanyBill>);
}
