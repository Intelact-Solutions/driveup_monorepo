export declare class CountrySupportRequestDto {
    country?: string;
    email?: string;
    message?: string;
    recaptchaToken?: string;
}
