export declare class ContactUsRequestDto {
    name?: string;
    email?: string;
    message?: string;
    recaptchaToken?: string;
}
