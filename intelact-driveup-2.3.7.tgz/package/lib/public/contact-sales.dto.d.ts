export declare class ContactSalesRequestDto {
    name?: string;
    email?: string;
    phone?: string;
    country?: string;
    subject?: string;
    message?: string;
    recaptchaToken?: string;
}
