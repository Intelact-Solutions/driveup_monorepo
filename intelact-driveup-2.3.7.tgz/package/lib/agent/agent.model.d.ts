import { BankAccount, StatusType } from "@driveup/shared";
import { Metric } from "../metric/metric.model";
export declare class Agent {
    id: number;
    code: string;
    status: StatusType;
    percentage: number;
    bankAccount: BankAccount;
    totalPendingIncome: number;
    totalPaidIncome: number;
    metrics: Metric[];
    constructor(props?: Partial<Agent>);
}
