export declare class AgentClientsFilterDto {
    statuses: ('active' | 'expired')[];
    phrase: string;
    sortLogic: 'clientName' | 'location' | 'endDate' | 'amount';
    sortOrder: 'asc' | 'desc';
}
