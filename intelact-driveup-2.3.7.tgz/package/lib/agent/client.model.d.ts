import { Company } from "../company/company.model";
export declare class AgentClient extends Company {
    endDate: Date;
    totalEarning: number;
    location: string;
    /************************* methods *************************/
    constructor(props?: Partial<AgentClient>);
}
