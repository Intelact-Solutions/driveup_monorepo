export declare class AgentCode {
    id: number;
    code: string;
    title: string;
    description: string;
    /**
     * The percentage of the agents income
     */
    percentage: number;
    /************************* methods *************************/
    constructor(props?: Partial<AgentCode>);
}
