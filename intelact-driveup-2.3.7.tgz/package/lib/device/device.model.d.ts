export declare class Device {
    id: number;
    guid: string;
    model: string;
    name: string;
    brand: string;
    os: string;
    language: string;
    description: string;
    constructor(props?: Partial<Device>);
}
