export declare class DeviceSignatureDto {
    guid: string;
    signature: string;
}
