/**
 * Browser user device (agent)
 * Trace device information for auth or analytic purpose
 *
 * @copyright Intelact Soltions Ltd.
 */
export interface IDeviceAgent {
    /**
     * Custom globally-unique IDs
     * Store this UUID in device to reuse for device identification
     * This property is mandatory
     */
    guid: string;
    /**
     * Request origin
     */
    origin: string;
    /**
     * Model (iPhone, Galaxy 21s)
     */
    model: string;
    /**
     * Device name
     * John'sIPhone
     */
    name: string;
    /**
     * Brand name (Apple, Samsung, Google)
     */
    brand: string;
    /**
     * Operating system
     */
    os: string;
    /**
     * OS Version
     */
    osVersion: string;
    /**
     * App version
     */
    appVersion: string;
    /**
     * Language
     */
    language: string;
    /**
     * Parsed server description
     */
    description: string;
}
