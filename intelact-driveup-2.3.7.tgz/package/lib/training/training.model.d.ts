import { CarTransmission, CourseType, Note, StatusType, TrainingType } from "@driveup/shared";
import { Appointment } from "../calendar/appointment";
import { Company } from "../company/company.model";
import { CoursePart } from "../course/part.model";
import { DrivingCategory } from "../driving/category/category.model";
import { PickupLocation } from "../geo/pickup.model";
import { Instructor } from "../instructor/instructor.model";
import { License } from "../license/license.model";
import { Student } from "../student/student.model";
export declare class Training {
    id: number;
    /************************* company *************************/
    company: Company;
    /************************* instructor *************************/
    instructor: Instructor;
    /************************* student *************************/
    student: Student;
    appointments: Appointment[];
    /************************* upcoming *************************/
    nextPart: string;
    nextSession: Date;
    /************************* location *************************/
    location: string;
    /************************* info *************************/
    name: string;
    description: string;
    type: TrainingType;
    status: StatusType;
    /**
     * Wether or not the student can manage appointments in the calendar
     */
    calendarEnabled: boolean;
    /**
     * Student rating to the company, from 1 to 5
     */
    studentRating: number;
    /************************* progress *************************/
    progress: number;
    /************************* finances *************************/
    cost: number;
    /**
     * 0 => the student has paid what they need to pay
     * Minus balance => the student must pay the balance amount
     * Plus balance => the student has paid more that they needed to
     */
    balance: number;
    paid: number;
    /**
     * The sum of the discounts created for this training
     */
    discount: number;
    /**
     * The sum of the refunds created for this training
     */
    refund: number;
    totalPayments: number;
    /************************* driving training progress *************************/
    remainingAppointments: number;
    completedTopics: number;
    totalTopics: number;
    sessionDuration: number;
    /************************* driving category *************************/
    category: DrivingCategory;
    /************************* course training progress *************************/
    /**
     * For fixed courses represents absent parts
     *
     * For flexible courses represents absent appointments
     */
    absent: number;
    presentParts: number;
    remainingParts: number;
    totalParts: number;
    /************************* course type *************************/
    courseType: CourseType;
    /************************* course id *************************/
    courseId: number;
    /************************* last viewed driving topic id *************************/
    lastViewedTopicId: number;
    /************************* tracks *************************/
    createdBy: any;
    createdOn: Date;
    completedBy: any;
    completedOn: Date;
    archivedBy: any;
    archivedOn: Date;
    terminatedBy: any;
    terminatedOn: Date;
    terminationNote: Note;
    /************************* driving *************************/
    transmission: CarTransmission;
    license: License;
    sessionPrice: number;
    administrationFee: number;
    totalSessionsFee: number;
    pickupLocation: PickupLocation;
    totalAppointments: number;
    estimatedExamDate: Date;
    /************************* course *************************/
    parts: CoursePart[];
    price: number;
    constructor(props?: Partial<Training>);
    isDriving(): boolean;
    isCourse(): boolean;
    isInProgress(): boolean;
    isCompleted(): boolean;
    isTerminated(): boolean;
}
