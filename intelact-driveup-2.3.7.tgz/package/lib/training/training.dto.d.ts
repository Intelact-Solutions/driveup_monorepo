import { CarTransmission, Person, StatusType, TrainingType } from "@driveup/shared";
export declare class TrainingRatingDto {
    rating: number;
}
export declare class InstructorTrainingFilterDto {
    statuses: StatusType[];
    categories: number[];
    students: number[];
    negativeBalance: boolean;
    positiveBalance: boolean;
    phrase: string;
    /**
     * Weather or not only own trainings should be loaded. Own trainings are trainings where the instructor is assigned as the in-charge instructor.
     */
    ownTrainingsOnly: boolean;
    sortOrder: 'asc' | 'desc';
    sortLogic: 'alph' | 'chron';
}
export declare class CompanyTrainingFilterDto {
    types: TrainingType[];
    statuses: StatusType[];
}
export declare class CourseTrainingFilterDto {
    statuses: StatusType[];
    courses: number[];
    instructors: number[];
    incompleteSchedule: boolean;
    negativeBalance: boolean;
    positiveBalance: boolean;
    phrase: string;
    startDate: Date;
    endDate: Date;
    sortOrder: 'asc' | 'desc';
    sortLogic: 'student' | 'status' | 'instructor' | 'createdOn' | 'balance';
}
export declare class DrivingTrainingFilterDto {
    statuses: StatusType[];
    categories: number[];
    instructors: number[];
    negativeBalance: boolean;
    positiveBalance: boolean;
    phrase: string;
    startDate: Date;
    endDate: Date;
    sortOrder: 'asc' | 'desc';
    sortLogic: 'student' | 'status' | 'instructor' | 'createdOn' | 'balance';
}
export declare class CreateTrainingDto {
    person: Person;
}
export declare class CreateDrivingTrainingDto extends CreateTrainingDto {
    transmission: CarTransmission;
}
export declare class DrivingTransmissionDto {
    transmission: CarTransmission;
}
