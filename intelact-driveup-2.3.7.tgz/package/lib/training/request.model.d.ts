import { CarTransmission, StatusType, TrainingType } from "@driveup/shared";
import { Company } from "../company/company.model";
import { Course } from "../course/course.model";
import { DrivingCategory } from "../driving/category/category.model";
export declare class TrainingRequest {
    id: number;
    preferredStartDate: Date;
    type: TrainingType;
    status: StatusType;
    /************************* company *************************/
    company: Company;
    /************************* course **************************/
    course: Course;
    /************************* driving *************************/
    transmission: CarTransmission;
    drivingCategory: DrivingCategory;
    /************************* tracks *************************/
    createdBy: any;
    createdOn: Date;
    acceptedBy: any;
    acceptedOn: Date;
    rejectedBy: any;
    rejectedOn: Date;
    constructor(props?: Partial<TrainingRequest>);
}
