import { StatusType } from "@driveup/shared";
export declare class TrainingRequestFilterDto {
    status: StatusType;
}
