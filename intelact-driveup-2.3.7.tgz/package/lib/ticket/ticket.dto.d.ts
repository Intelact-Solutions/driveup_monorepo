import { TicketType } from "@driveup/shared";
export declare class TicketSubmitDto {
    name?: string;
    description?: string;
    type: TicketType;
    /************************* Enterprise plan request *************************/
    teamMembers?: number;
    email?: string;
    phone?: string;
}
export declare class TicketFilterDto {
    type: TicketType;
}
