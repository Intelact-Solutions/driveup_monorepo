import { TicketType } from "@driveup/shared";
export declare class Ticket {
    name: string;
    description: string;
    image: string;
    type: TicketType;
    completed: boolean;
    createdOn: Date;
    /************************* Methods *************************/
    constructor(props?: Partial<Ticket>);
}
