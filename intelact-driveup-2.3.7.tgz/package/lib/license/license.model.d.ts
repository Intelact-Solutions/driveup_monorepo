export declare class License {
    id: number;
    number: string;
    referenceNumber: string;
    expiry: Date;
    constructor(props?: Partial<License>);
}
