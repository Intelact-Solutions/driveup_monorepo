export declare class IDsDto {
    ids: number[];
}
