export declare class ProfileDependency {
    title: string;
    subtitle: string;
    constructor(props?: Partial<ProfileDependency>);
}
