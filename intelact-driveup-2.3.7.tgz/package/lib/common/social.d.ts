export declare class SocialLink {
    title: string;
    url: string;
}
export declare class SocialLinksDto {
    socials: SocialLink[];
}
