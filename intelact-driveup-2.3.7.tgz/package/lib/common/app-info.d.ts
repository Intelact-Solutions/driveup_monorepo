import { Language, Link } from "@driveup/shared";
export declare class AppInfo {
    name: string;
    slogan: string;
    url: string;
    email: string;
    version: string;
    environment: string;
    logo: string;
    symbol: string;
    apiVersion: string;
    appVersion: string;
    language: Language;
    maintenanceMode: boolean;
    latestVersion: number;
    lastSupportedVersion: number;
    appStoreLink: string;
    googlePlayLink: string;
    links: Link[];
    constructor(props?: Partial<AppInfo>);
}
