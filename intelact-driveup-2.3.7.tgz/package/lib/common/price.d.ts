export declare class PriceDto {
    price: number;
}
