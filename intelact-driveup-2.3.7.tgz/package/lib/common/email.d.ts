export declare class EmailDto {
    email: string;
    otp: string;
}
