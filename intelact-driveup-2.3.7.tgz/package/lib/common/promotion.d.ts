export declare class PromotionCodeDto {
    promotionCode: string;
}
