import { Language } from "@driveup/shared";
export declare class LanguageDto {
    language: Language;
}
