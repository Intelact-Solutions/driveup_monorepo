import { Language } from "@driveup/shared";
export declare class NameDto {
    name: string;
}
export declare class TitleDto {
    title: string;
}
export declare class DescriptionDto {
    description: string;
}
export declare class BooleanValueDto {
    value: boolean;
}
export declare class MessageDto {
    message: string;
}
export declare class TranslateDto {
    field?: string;
    language: Language;
    content: string;
}
