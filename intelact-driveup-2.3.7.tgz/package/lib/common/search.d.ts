export declare class PhraseSearchDto {
    phrase: string;
}
