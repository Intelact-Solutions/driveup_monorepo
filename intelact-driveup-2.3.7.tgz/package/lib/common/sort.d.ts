export declare class SortListDto {
    ids: number[];
}
export declare class SortOrderDto {
    logic: 'alph' | 'chron';
    order: 'asc' | 'desc';
}
