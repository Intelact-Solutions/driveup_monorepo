import { IDeviceAgent } from "../device/device.agent";
export declare class SigninDto {
    phone: string;
    otp: string;
    device: IDeviceAgent;
}
