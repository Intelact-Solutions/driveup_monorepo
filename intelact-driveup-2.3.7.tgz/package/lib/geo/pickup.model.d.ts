import { Coordinate } from "@driveup/shared";
export declare class PickupLocation {
    id: number;
    title: string;
    address: string;
    coordinate?: Coordinate;
    constructor(props?: Partial<PickupLocation>);
}
export declare class PickupLocationsDto {
    pickupLocations: PickupLocation[];
}
