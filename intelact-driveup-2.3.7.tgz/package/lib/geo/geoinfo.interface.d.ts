import { Language } from "@driveup/shared";
export interface IGeoInfo {
    languages: Language[];
    language: Language;
    countryCode: string;
    countrySupported?: boolean;
    countryName?: string;
    ipVersion?: string;
    ipAddress?: string;
    latitude?: string;
    longitude?: string;
    city?: string;
    postalCode?: string;
    timezone?: string;
    regionName?: string;
    regionCode?: string;
}
