import { Coordinate } from "@driveup/shared";
/**
 * Address can be null or undefined in this dto
 */
export declare class AddressDto {
    address: string;
}
export declare class ZipCodeDto {
    zipCode: string;
}
export declare class LocationDto {
    location: string;
}
export declare class FullAddressDto {
    address: string;
    zipCode: string;
    location: string;
    coord: Coordinate;
}
