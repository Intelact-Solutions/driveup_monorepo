import { BankAccount, StatusType } from "@driveup/shared";
export declare class AgentPayout {
    id: number;
    status: StatusType;
    startDate: Date;
    endDate: Date;
    bank: BankAccount;
    amount: number;
    createdBy: any;
    createdOn: Date;
    constructor(props?: Partial<AgentPayout>);
}
