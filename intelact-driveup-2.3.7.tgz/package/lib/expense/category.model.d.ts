import { Language } from "@driveup/shared";
export declare class ExpenseCategory {
    id: number;
    name: string;
    title: string;
    description: string;
    icon: string;
    /************************* translations *************************/
    translations: ExpenseCategoryTranslation[];
    constructor(props?: Partial<ExpenseCategory>);
}
export declare class ExpenseCategoryTranslation {
    id: number;
    language: Language;
    title: string;
    description: string;
    constructor(props?: Partial<ExpenseCategoryTranslation>);
}
