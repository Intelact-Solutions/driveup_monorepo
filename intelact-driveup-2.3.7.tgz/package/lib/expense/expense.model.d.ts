import { StatusType } from "@driveup/shared";
import { ExpenseCategory } from "./category.model";
export declare class Expense {
    id: number;
    status: StatusType;
    category: ExpenseCategory;
    amount: number;
    description: string;
    receiptUrl: string;
    createdBy: any;
    createdOn: Date;
    approvedBy: any;
    approvedOn: Date;
    canceledBy: any;
    canceledOn: Date;
    rejectedBy: any;
    rejectedOn: Date;
    constructor(props?: Partial<Expense>);
}
