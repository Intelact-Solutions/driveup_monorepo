import { Language, StatusType } from "@driveup/shared";
export declare class ExpenseCreateDto {
    amount: number;
    categoryId: number;
    description: string;
}
export declare class ExpenseUpdateDto {
    amount: number;
    categoryId: number;
    description: string;
    removeReceipt: boolean;
}
export declare class CompanyExpenseFilterDto {
    startDate: Date;
    endDate: Date;
    categories: number[];
    instructorId: number;
    statuses: StatusType[];
    phrase: string;
    sortLogic: 'createdBy' | 'createdOn' | 'category' | 'amount' | 'status';
    sortOrder: 'asc' | 'desc';
}
export declare class SystemExpenseTranslationDto {
    id: number;
    language: Language;
    title: string;
    description: string;
}
