import { AppointmentType, CarTransmission } from '@driveup/shared';
import { DrivingCategory } from '../driving/category/category.model';
import { DrivingSessionTopic } from '../session/driving/session.topic';
import { Instructor } from '../instructor/instructor.model';
import { CoursePartDefinition } from '../course/definition.model';
import { Student } from '../student/student.model';
import { PickupLocation } from '../geo/pickup.model';
export declare class Appointment {
    id: number;
    trainingId: number;
    /**
     * The global identifier of the appointment. can be used to search for the appointment by this number
     */
    number: number;
    type: AppointmentType;
    student: Student;
    instructor: Instructor;
    title: string;
    subtitle: string;
    description: string;
    startDate: Date;
    endDate: Date;
    /**
     * Appointment is disabled for editing (belongs to someone else)
     */
    disabled: boolean;
    /**
     * Canceled appointment
     */
    cancelled: boolean;
    /**
     * Completed appointment
     */
    completed: boolean;
    /**
     * All day appointment (event - holiday)
     */
    allday: boolean;
    /**
     * Busy time slot in the calendar (driving appointment, course appointment, event/task)
     */
    busy: boolean;
    /**
     * Disabled slot in the calendar (holiday - non working hours)
     */
    disabledSlot: boolean;
    /********** trainings **********/
    involvedInstructors: number[];
    canSeeTrainingDetails: boolean;
    /********** driving fields **********/
    /**
     * Whether the appointment is a driving exam
     */
    isExam: boolean;
    isFixed: boolean;
    isFlexible: boolean;
    /**
     * Pickup location for the driving session
     */
    pickupLocation: PickupLocation;
    /**
     * Custom pickup location for the driving session
     * If set, pickupLocation will be ignored
     */
    customPickupLocation: string;
    transmission: CarTransmission;
    drivingCategory: DrivingCategory;
    topics: DrivingSessionTopic[];
    /************************* score *************************/
    /**
     * Average score of the topics touched in this appointment
     */
    score: number;
    /************************* obligation period *************************/
    hasObligationPeriod: boolean;
    hoursBeforeObligationPeriod: number;
    /************************* course *************************/
    remainingSeats: number;
    /**
     * Whether or not the student has attended the appointment
     */
    attended: boolean;
    definition: CoursePartDefinition;
    courseId: number;
    takenSeats: number;
    presentStudents: number;
    /************************* methods *************************/
    constructor(props?: Partial<Appointment>);
    isDriving(): boolean;
    isCourse(): boolean;
    isTask(): boolean;
}
