export declare class DateDto {
    date: Date;
}
export declare class Period {
    startDate: Date;
    endDate: Date;
    constructor(props?: Partial<Period>);
    /**
     * Check if this period collides with another period. the other period's startDate can be empty
     *
     * Throws error if any of the dates are missing (for this date or the other date)
     * @param Period other
     * @returns currentPeriod.startDate < otherPeriod.endDate && currentPeriod.endDate > otherPeriod.startDate
     */
    collidesWith(other: Period): boolean;
}
export declare class ObligationPeriodDto {
    obligationPeriod: number;
}
export declare class MonthYearDto {
    month?: number;
    year?: number;
}
