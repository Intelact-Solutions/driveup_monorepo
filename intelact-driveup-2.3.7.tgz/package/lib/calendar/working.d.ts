import { Period } from "./date";
import { WeekDay } from "@driveup/shared";
export declare class WorkdayDefinition {
    weekday: WeekDay;
    periods: Period[];
}
export declare class WorkingHoursDto {
    definitions: WorkdayDefinition[];
}
