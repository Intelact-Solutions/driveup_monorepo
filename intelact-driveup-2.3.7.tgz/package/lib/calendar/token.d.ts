import { ProfileType } from "@driveup/shared";
export interface ICalendarToken {
    /**
     * The profile ID
     */
    profileId: number;
    /**
     * Whether or not show only "busy" title without details about the calendar appointments and events
     */
    busy: 'true' | 'false';
    /**
     * The profile type
     */
    profileType: ProfileType;
}
