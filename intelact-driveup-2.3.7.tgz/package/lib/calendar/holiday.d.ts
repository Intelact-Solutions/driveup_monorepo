import { Holiday } from "@driveup/shared";
/**
 * Holiday Model
 */
export declare class HolidaysDto {
    holidays: Holiday[];
}
