import { Language } from "@driveup/shared";
import { Currency } from "../currency/currency.model";
import { Metric } from "../metric/metric.model";
export declare class Country {
    id: number;
    name: string;
    localName: string;
    abbr: string;
    languages: Language[];
    phoneCode: string;
    phoneFormat: string;
    flagUrl: string;
    vat: number;
    active: boolean;
    selected: boolean;
    currency: Currency;
    metrics: Metric[];
    constructor(props?: Partial<Country>);
}
