import { Language } from "@driveup/shared";
export declare class CountrySearchDto {
    name: string;
    active: boolean;
}
export declare class CountryCreateDto {
    name: string;
    localName: string;
    abbr: string;
    currencyId: number;
    languages: Language[];
    phoneCode: string;
    vat: number;
}
export declare class CountryUpdateDto {
    name: string;
    localName: string;
    abbr: string;
    languages: Language[];
    phoneCode: string;
    vat: number;
    active: boolean;
    currencyId: number;
}
