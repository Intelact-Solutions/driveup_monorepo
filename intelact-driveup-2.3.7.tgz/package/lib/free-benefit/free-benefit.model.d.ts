import { FreeBenefitType } from "@driveup/shared";
export declare class FreeBenefit {
    type: FreeBenefitType;
    quantity: number;
    /************************* methods *************************/
    constructor(props?: Partial<FreeBenefit>);
}
