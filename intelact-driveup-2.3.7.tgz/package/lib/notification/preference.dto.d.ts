export declare class NotificationPreferenceDto {
    name: string;
    active: boolean;
    companyId?: number;
}
