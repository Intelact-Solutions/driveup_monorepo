export declare class NotificationPreference {
    name: string;
    title: any;
    description: any;
    active: boolean;
    readonly: boolean;
    constructor(props?: Partial<NotificationPreference>);
}
