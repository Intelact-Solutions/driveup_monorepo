import { ColorContext, Person } from "@driveup/shared";
export declare class Notification {
    id: number;
    title: string;
    message: string;
    context: ColorContext;
    seen: boolean;
    link: string;
    createdOn: Date;
    author: Person;
    target: Person;
    constructor(props?: Partial<Notification>);
}
