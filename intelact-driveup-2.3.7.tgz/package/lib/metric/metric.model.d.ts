/**
 * General model for metric representaion in the system
 */
export declare class Metric {
    /**
     * Metric name identifier
     */
    name: string;
    /**
     * Metric label name
     */
    label?: string;
    /**
     * Metric description (usefull for tooltip)
     */
    description?: string;
    /**
     * Metric value
     */
    value: number;
    /**
     * Indicate activ state (usefull for logged user)
     */
    active: boolean;
    /**
     * Metric icon representation
     */
    icon: string;
    /**
     * Show label indicator
     */
    showLabel: boolean;
    constructor(props?: Partial<Metric>);
    /**
     * Toggle metric state
     * Increase/Decrease metric value
     * Activate/deactivate metric state
     */
    toggleState(): void;
    increase(): void;
    decrease(): void;
    static toInstance(data: object): Metric;
}
