import { Feature } from "@driveup/shared";
export declare class Log {
    type: Feature;
    event: string;
    content: string;
    createdOn: Date;
    constructor(props?: Partial<Log>);
}
