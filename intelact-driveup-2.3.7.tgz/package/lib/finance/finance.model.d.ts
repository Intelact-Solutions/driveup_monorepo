import { BankAccount, PaymentType, StatusType, TrainingType, TransactionType } from "@driveup/shared";
import { Training } from "../training/training.model";
import { ExpenseCategory } from "../expense/category.model";
import { Student } from "../student/student.model";
export declare class Finance {
    id: number;
    type: TransactionType;
    paymentType: PaymentType;
    trainingType: TrainingType;
    amount: number;
    balance: number;
    description: string;
    status: StatusType;
    receiptUrl: string;
    createdBy: any;
    createdOn: Date;
    approvedBy: any;
    approvedOn: Date;
    canceledBy: any;
    canceledOn: Date;
    rejectedBy: any;
    rejectedOn: Date;
    training: Training;
    /**
     * TODO: change field name to referenceItem.
     * originalItem is not a good name anymore, since we don't show the cancellation items in the list.
     * and the cancellation item info is being returned in this field now, so the name originalItem will be confusing in the future.
     * */
    originalItem: Finance;
    student: Student;
    expenseCategory: ExpenseCategory;
    bank: BankAccount;
    constructor(props?: Partial<Finance>);
}
