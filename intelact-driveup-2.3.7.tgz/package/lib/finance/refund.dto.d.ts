export declare class SubmitRefundDto {
    amount: number;
    description: string;
}
