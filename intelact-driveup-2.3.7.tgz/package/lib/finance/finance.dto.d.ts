import { PaymentType, StatusType, TrainingType, TransactionType } from "@driveup/shared";
export declare class CompanyBankInfoSubmitDto {
    IBAN: string;
    taxId: string;
}
export declare class CompanyFinancialFlowFilterDto {
    startDate: Date;
    endDate: Date;
    registeredBy: number;
    financeTypes: TransactionType[];
    paymentTypes: PaymentType[];
    trainingTypes: TrainingType[];
    statuses: StatusType[];
    phrase: string;
    sortLogic: 'financeType' | 'studentName' | 'createdOn' | 'amount' | 'status';
    sortOrder: 'asc' | 'desc';
}
export declare class FinanceFilterDto {
    types: TransactionType[];
    startDate: Date;
    endDate: Date;
    sortLogic: 'createdOn' | 'type' | 'amount' | 'registeredBy';
    sortOrder: 'asc' | 'desc';
}
export declare class FinanceSortDto {
    sortLogic: 'createdOn' | 'amount';
    sortOrder: 'asc' | 'desc';
}
export declare class CompanyStudentDebtFilterDto {
    trainingTypes: TrainingType[];
    categories: number[];
    statuses: StatusType[];
    /** Only load debts more than this value */
    minDebt: number;
    phrase: string;
    sortLogic: 'student' | 'status' | 'debt';
    sortOrder: 'asc' | 'desc';
}
export declare class HandoverTransactionStatusDto {
    status: StatusType;
}
export declare class CompanyOnlineTransactionFilterDto {
    statuses: StatusType[];
    startDate: Date;
    endDate: Date;
    phrase: string;
    sortLogic: 'createdOn' | 'registeredBy' | 'amount' | 'studentName' | 'status';
    sortOrder: 'asc' | 'desc';
}
export declare class CompanyOnlineTransactionBulkUpdateDto {
    approvedDrivingPayments?: number[];
    approvedCoursePayments?: number[];
    canceledDrivingPayments?: number[];
    canceledCoursePayments?: number[];
    cancellationDescription?: string;
}
