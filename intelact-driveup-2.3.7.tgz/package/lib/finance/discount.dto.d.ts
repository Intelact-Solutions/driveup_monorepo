export declare class SubmitDiscountDto {
    amount: number;
    description: string;
}
