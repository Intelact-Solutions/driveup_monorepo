import { PaymentType } from "@driveup/shared";
export declare class SubmitPaymentDto {
    amount: number;
    description: string;
    type: PaymentType;
}
