import { PaymentProvider, StatusType } from "@driveup/shared";
export declare class CompanyPayment {
    id: number;
    amount: number;
    provider: PaymentProvider;
    status: StatusType;
    date: Date;
    /************************* methods *************************/
    constructor(props?: Partial<CompanyPayment>);
}
