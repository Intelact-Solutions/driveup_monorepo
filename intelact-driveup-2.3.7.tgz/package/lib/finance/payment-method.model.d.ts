import { CompanyPayment } from "./company-payment.model";
import { Item } from "../item/item.model";
export declare class CompanyPaymentMethod {
    id: number;
    name: string;
    icon: string;
    active: boolean;
    pending: boolean;
    details: Item[];
    warnings: string[];
    failedPayments: CompanyPayment[];
    /**
     * A description summarizing the failed payments associated with this payment method
     */
    failedPaymentsDescription: string;
    providerPaymentMethodId: string;
    providerCustomerId: string;
    /************************* methods *************************/
    constructor(props?: Partial<CompanyPaymentMethod>);
}
