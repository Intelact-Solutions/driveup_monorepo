export declare class TaskCreateDto {
    instructorId: number;
    title: string;
    startDate: Date;
    endDate: Date;
    allDay: boolean;
    busy: boolean;
}
export declare class TaskUpdateDto {
    instructorId: number;
    title: string;
    startDate: Date;
    endDate: Date;
    allDay: boolean;
    busy: boolean;
}
export declare class TaskFilterDto {
    instructors: number[];
    title: string;
    startDate: Date;
    endDate: Date;
    allDay: boolean;
    busy: boolean;
}
