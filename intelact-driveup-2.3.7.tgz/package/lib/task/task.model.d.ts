export declare class Event {
    id: number;
    title: string;
    startDate: Date;
    endDate: Date;
    allDay: boolean;
    constructor(props?: Partial<Event>);
}
