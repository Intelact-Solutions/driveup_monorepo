import { Language } from "@driveup/shared";
export declare class CompanySubmitCategoryDto {
    duration: number;
    price: number;
    administrationFee: number;
    affectCurrentTrainings: boolean;
    active: boolean;
    seedTopics: boolean;
}
/**
 * @deprecated
 * Use CompanySubmitCategoryDto instead
 */
export declare class CompanyActivateCategoryDto extends CompanySubmitCategoryDto {
}
export declare class CompanyCategoryPriceDto {
    price: number;
}
export declare class CompanyCategoryDurationDto {
    duration: number;
}
export declare class CompanyCategoryAdministrationFeeDto {
    administrationFee: number;
}
export declare class SystemDrivingCategoryCreateDto {
    name: string;
    groupName: string;
    minAge: number;
}
export declare class SystemDrivingCategoryMinAgeDto {
    minAge: number;
}
export declare class SystemDrivingCategoryTranslationCreateDto {
    language: Language;
    title: string;
    description: string;
}
