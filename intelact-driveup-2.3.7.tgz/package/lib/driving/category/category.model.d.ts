import { ColorContext, Language } from "@driveup/shared";
import { Country } from "../../country/country.model";
export declare class DrivingCategory {
    id: number;
    groupName: string;
    name: string;
    title: string;
    description: string;
    active: boolean;
    icon: string;
    minAge: number;
    country: Country;
    context: ColorContext;
    /************** company definitions **************/
    sessionPrice: number;
    sessionDuration: number;
    administrationFee: number;
    administrationFeeStatus: boolean;
    /************************* translations *************************/
    translations: {
        language: Language;
        title: string;
        description?: string;
    }[];
    /************************* topics and skills *************************/
    /**
     * Total number of topics
     */
    topics: number;
    /**
     * Total number of skills
     */
    skills: number;
    constructor(props?: Partial<DrivingCategory>);
}
