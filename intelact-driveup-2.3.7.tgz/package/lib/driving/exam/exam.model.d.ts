import { Feedback, StatusType } from "@driveup/shared";
export declare class DrivingExam {
    id: number;
    examFeedback: Feedback;
    examStatus: StatusType;
    examinerName: string;
    constructor(props?: Partial<DrivingExam>);
}
