import { Feedback, StatusType } from "@driveup/shared";
export declare class ExamStatusDto {
    status: StatusType;
}
export declare class ExamFeedbackDto {
    examinerName: string;
    feedback: Feedback;
}
