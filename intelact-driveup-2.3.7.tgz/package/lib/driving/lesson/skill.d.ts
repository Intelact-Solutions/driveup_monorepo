import { Language, Score } from '@driveup/shared';
export declare class DrivingSkill {
    id: number;
    title: string;
    sort: number;
    score: Score;
    translations: {
        language: Language;
        title: string;
        description?: string;
    }[];
    constructor(props?: Partial<DrivingSkill>);
}
