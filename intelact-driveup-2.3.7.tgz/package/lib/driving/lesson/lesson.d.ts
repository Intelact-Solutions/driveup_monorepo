import { DrivingTopic } from "./topic";
export declare class DrivingLesson {
    id: number;
    title: string;
    description: string;
    imageUrl: string;
    sort: number;
    topics: DrivingTopic[];
    constructor(props?: Partial<DrivingLesson>);
}
