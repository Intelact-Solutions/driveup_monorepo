import { StatusType } from "@driveup/shared";
export declare class TopicSubmitDto {
    title: string;
    description: string;
    deleteImage: boolean;
    skills: {
        id: number;
        title: string;
    }[];
}
export declare class TopicsSortDto {
    lessonId: number;
    topics: number[];
}
export declare class DrivingTopicFilterDto {
    status: StatusType;
    title: string;
}
