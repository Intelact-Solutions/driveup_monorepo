import { Score } from '@driveup/shared';
export declare class CompanySkillSubmitDto {
    title: string;
}
export declare class SkillScoreDto {
    score: Score;
}
