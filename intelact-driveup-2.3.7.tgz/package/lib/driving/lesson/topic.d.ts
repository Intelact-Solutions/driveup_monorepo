import { DrivingSkill } from './skill';
import { Language } from '@driveup/shared';
export declare class DrivingTopic {
    id: number;
    title: string;
    description: string;
    icon: string;
    sort: number;
    score: number;
    done: boolean;
    repetitions: number;
    upcoming: boolean;
    skills: DrivingSkill[];
    translations: {
        language: Language;
        title: string;
        description?: string;
    }[];
    constructor(props?: Partial<DrivingTopic>);
}
