import { PricePlanFeature, PricePlanType } from "@driveup/shared";
export declare class PricePlanFilterDto {
    active: boolean;
    countryId: number;
}
export declare class SystemPricePlanSubmitDto {
    name?: string;
    type: PricePlanType;
    price: number;
    startCredit: number;
    features?: PricePlanFeature[];
    minUsers?: number;
}
