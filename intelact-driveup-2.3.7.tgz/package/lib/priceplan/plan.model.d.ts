import { PricePlanType } from '@driveup/shared';
import { Country } from "../country/country.model";
import { Item } from "../item/item.model";
export declare class PricePlan {
    id: number;
    country: Country;
    type: PricePlanType;
    name: string;
    title: string;
    description: string;
    startDate: Date;
    featured: boolean;
    icon: string;
    price: number;
    startCredit: number;
    active: boolean;
    /**
     * Only for company enterprise plan
     */
    maxSeats: number;
    /**
     * Only for company enterprise plan
     */
    takenSeats: number;
    upcoming: boolean;
    features: Item<string>[];
    usage: Item<string>[];
    priceLabel: {
        header: string;
        banner: string;
        unit: string;
    };
    statusBanner: {
        label: string;
        action: string;
    };
    constructor(props?: Partial<PricePlan>);
}
