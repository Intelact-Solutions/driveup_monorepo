export declare class HandoverSubmitDto {
    approvedDrivingPayments: number[];
    approvedCoursePayments: number[];
    approvedExpenses: number[];
    rejectedExpenses: number[];
}
