import { Expense } from "../expense/expense.model";
import { Finance } from "../finance/finance.model";
import { Instructor } from "../instructor/instructor.model";
export declare class Handover {
    id: number;
    createdOn: Date;
    handoverInstructor: Instructor;
    handoverManager: Instructor;
    approvedPayments: Finance[];
    approvedExpenses: Expense[];
    rejectedExpenses: Expense[];
    /************************* functions *************************/
    constructor(props?: Partial<Handover>);
}
