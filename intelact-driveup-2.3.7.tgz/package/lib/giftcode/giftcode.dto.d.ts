export declare class CompanyGiftCodeSubmitDto {
    code: string;
}
export declare class SystemGiftCodeSubmitDto {
    countryId: number;
    groupId: number;
    code: string;
    amount: number;
    expiryDate: Date;
    maxUses: number;
}
export declare class SystemGiftCodeGroupUpdateDto {
    countryId: number;
    name: string;
    description: string;
}
export declare class SystemGiftCodeGroupCreateDto {
    countryId: number;
    name: string;
    description: string;
    /**
     * Number of codes to be automatically generated
     */
    numberOfCodes: number;
    /**
     * If the "numberOfCodes" is set, this is the amount for each code
     */
    amountOfCodes: number;
    /**
     * If the "numberOfCodes" is set, this is the maximum number of uses for each code
     */
    maxUsesPerCode: number;
    /**
     * If the "numberOfCodes" is set, this is the expiry date for each code
     */
    expiryDateOfCodes: Date;
}
