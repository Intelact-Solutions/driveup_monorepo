import { Country } from "../country/country.model";
import { GiftCode } from "./giftcode.model";
export declare class GiftCodeGroup {
    id: number;
    createdOn: Date;
    country: Country;
    name: string;
    description: string;
    codes: GiftCode[];
    totalCodes: number;
    /************************* methods *************************/
    constructor(props?: Partial<GiftCodeGroup>);
}
