import { Company } from "../company/company.model";
import { Country } from "../country/country.model";
export declare class GiftCode {
    id: number;
    createdOn: Date;
    country: Country;
    code: string;
    amount: number;
    expiryDate: Date;
    maxUses: number;
    usesLeft: number;
    uses: {
        company: Company;
        date: Date;
    }[];
    active: boolean;
    /************************* methods *************************/
    constructor(props?: Partial<GiftCode>);
}
