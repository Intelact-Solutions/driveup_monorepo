export declare class ArrayHelper {
    /**
     * Get a random item from an array
     * @param val Given T type array
     * @returns Given T type
     */
    static getRandom<T>(val: T[]): T;
    /**
     * Get the last item from an array
     * @param val Given T type array
     * @returns Given T type
     */
    static getLastItem<T>(val: T[]): T;
    /**
     * Sum all numbers in a number array
     * @param val Number[]
     * @param toFixed (2)
     * @returns Sum number
     */
    static getSum(val: number[], toFixed?: number): number;
    /**
     * Get the average number in a number array
     * @param val Number[]
     * @param toFixed (2)
     * @returns Average number
     */
    static getAvg(val: number[], toFixed?: number): number;
}
