import { WeekDay } from '@driveup/shared';
import { DateTime, WeekdayNumbers } from 'luxon';
import { Appointment } from "../calendar/appointment";
import { Period } from "../calendar/date";
export declare class DateHelper {
    /**
     * Set timezone to date
     * @param date Date
     * @param timezone string
     * @returns Date
     */
    static setTimezone(date: Date, timezone: string): Date;
    /**
     * Format like 'October 14, 1983'
     * @param date Date
     * @param timezone string
     * @returns string
     */
    static toLocalDate(date: Date, timezone?: string): string;
    /**
     * Format like 'Oct 14, 1983, 9:30 AM'. Only 12-hour if the locale is.
     * @param date Date
     * @param timezone string
     * @returns string
     */
    static toLocalDateTime(date: Date, timezone?: string): string;
    /**
     * Format like 'Fri, 14 Oct 1983, 9:30 AM'. Only 12-hour if the locale is.
     * @param date Date
     * @param timezone string
     * @returns string
     */
    static toLocalWeekDayAndDateTime(date: Date, timezone?: string): string;
    /**
     * Is date between start and end dates
     * @param date Date
     * @param start Date
     * @param end Date
     * @returns
     */
    static isBetween(date: Date, start: Date, end: Date): boolean;
    /**
     * Converts a Date to a date-only string in the format "YYYY-MM-DD".
     * @param date Given date
     * @returns Date string
     */
    static toDateOnly(date: Date): string;
    /**
     * Converts a Date to a time-only string in the format "HH:MM:SS.sssZ".
     * @param date Given date
     * @returns Time string
     */
    static toTimeOnly(date: Date): string;
    /**
     * Get DateTime instance from Date
     * @param date
     * @returns DateTime
     */
    static toDateTimeInstance(date: Date): DateTime;
    /**
     * Check if date is start of day
     * @param date Given date
     * @returns True if date is start of day
     */
    static isStartOfDay(date: Date): boolean;
    /**
     * Check if date is end of day
     * @param date Given date
     * @returns True if date is end of day
     */
    static isEndOfDay(date: Date): boolean;
    /**
     * Converts a number to a WeekdayNumbers enum from luxon.
     * @param val
     * @returns
     */
    static toWeekdayNumber(val: number): WeekdayNumbers;
    /**
     * Converts a WeekDay enum from intelact/driveup to a WeekdayNumbers enum from luxon.
     * @param Weekday - The weekday to convert
     * @returns WeekdayNumbers from luxon - 1 to 7
     */
    static getWeekdayNumber(weekday: WeekDay): WeekdayNumbers;
    /**
     * Get WeekDay from DateTime
     * @param date
     * @returns WeekDay
     */
    static getWeekday(date: DateTime): WeekDay;
    /**
     * Converts a WeekDay enum from intelact/driveup to a MySQL weekday number.
     * @param Weekday - The weekday to convert
     * @returns number - MySQL weekday number (0 = Monday, 6 = Sunday)
     */
    static getMySqlWeekday(weekday: WeekDay): number;
    /**
     * Merge periods
     * @param Period[]
     * @returns Period[] - Returns an array of merged periods
     */
    static mergePeriods(periods: Period[]): Period[];
    /**
     * Merge appointment periods
     * @param Appointment[]
     * @returns Appointment[] - Returns an array of merged appointments
     */
    static mergeAppointmentPeriods(appointments: Appointment[]): Appointment[];
    /**
     * Get a formatted date string in "DD MMM YYYY" format,
     * or an empty string if the given date is invalid.
     * Example: "23 Oct 2025"
     * @param date string | number | Date
     * @param local Default de
     * @returns Formatted date string
     */
    static formatDate(date: string | number | Date, local?: string): string;
    /**
     * Get a formatted date and time string in "DD MMM YYYY - HH:MM" format,
     * or an empty string if the given date is invalid.
     * Example: "23 Oct 2025 - 14:30"
     * @param date string | number | Date
     * @param seperator Default '-'
     * @param local Default de
     * @returns Formatted date and time string
     */
    static formatDateAndTime(date: string | number | Date, seperator?: string, local?: string): string;
}
