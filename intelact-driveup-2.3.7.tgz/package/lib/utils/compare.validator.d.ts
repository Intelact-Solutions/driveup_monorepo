import { ValidationArguments, ValidatorConstraintInterface } from "class-validator";
/**
 * Checks if the start date is less than or equal to the end date
 * If one of the does not have a valid value, returns true
 */
export declare class CompareWithEndDate implements ValidatorConstraintInterface {
    validate(startDate: Date, args: ValidationArguments): boolean;
    defaultMessage(args?: ValidationArguments): string;
}
