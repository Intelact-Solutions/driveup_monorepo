import { ValidationArguments, ValidationOptions, ValidatorConstraintInterface } from "class-validator";
/**
 * Validator constraint that ensures two fields are both empty or both filled
 * Used for mutually dependent fields that should be set together
 */
export declare class MutuallyRequiredConstraint implements ValidatorConstraintInterface {
    /**
     * Validates that both fields are either empty or both have values
     * @param value - The value of the decorated field
     * @param args - Validation arguments containing the related field name
     * @returns True if both fields are empty or both have values, false otherwise
     */
    validate(value: any, args: ValidationArguments): boolean;
    /**
     * Returns the default error message when validation fails
     * @param args - Validation arguments
     * @returns Error message string
     */
    defaultMessage(args: ValidationArguments): string;
}
/**
 * Decorator that checks if two fields are mutually empty or both with value
 * Both fields must be either empty or filled together
 *
 * @param relatedField - The field name that needs to be checked with the decorated field
 * @param validationOptions - Optional class-validator validation options
 * @returns Property decorator function
 *
 * @example
 * ```typescript
 * class MyDto {
 *   @MutuallyRequired('endDate')
 *   startDate: Date;
 *
 *   endDate: Date;
 * }
 * ```
 */
export declare function MutuallyRequired(relatedField: string, validationOptions?: ValidationOptions): (object: Object, propertyName: string) => void;
/**
 * Validator constraint that ensures at least one of two fields has a value
 * Used for fields where at least one must be provided
 */
export declare class EitherRequiredConstraint implements ValidatorConstraintInterface {
    /**
     * Validates that at least one of the two fields has a value
     * @param value - The value of the decorated field
     * @param args - Validation arguments containing the related field name
     * @returns True if at least one field has a value, false if both are empty
     */
    validate(value: any, args: ValidationArguments): boolean;
    /**
     * Returns the default error message when validation fails
     * @param args - Validation arguments
     * @returns Error message string
     */
    defaultMessage(args: ValidationArguments): string;
}
/**
 * Decorator that checks if at least one of two fields has a value
 * At least one field must be provided
 *
 * @param relatedField - The field name that needs to be checked with the decorated field
 * @param validationOptions - Optional class-validator validation options
 * @returns Property decorator function
 *
 * @example
 * ```typescript
 * class MyDto {
 *   @EitherRequired('email')
 *   phone: string;
 *
 *   email: string;
 * }
 * ```
 */
export declare function EitherRequired(relatedField: string, validationOptions?: ValidationOptions): (object: Object, propertyName: string) => void;
