/**
 * Transforms a value to an array of numbers
 * Handles comma-separated strings, single values, and arrays
 * Filters out NaN values
 * @returns A class-transformer decorator
 */
export declare function ToNumberArray(): PropertyDecorator;
export declare function RemoveSpaces(): PropertyDecorator;
/**
 * Transforms a value to an array of strings
 * Handles comma-separated strings, single values, and arrays
 * Trims and filters out empty strings
 * @returns A class-transformer decorator
 */
export declare function ToStringArray(): PropertyDecorator;
/**
 * Transforms a value to an enum type
 * Matches by value or key (case-insensitive)
 * @template E - The enum type
 * @param enumType - The enum object to transform to
 * @returns A class-transformer decorator
 */
export declare function ToEnum<E extends object>(enumType: E): PropertyDecorator;
/**
 * Transforms a value to an array of enum values
 * Matches by value or key (case-insensitive)
 * @template E - The enum type
 * @param enumType - The enum object to transform to
 * @returns A class-transformer decorator
 */
export declare function ToEnumArray<E extends object>(enumType: E): PropertyDecorator;
/**
 * Transforms a value to a number
 * Returns original value if conversion results in NaN
 * @returns A class-transformer decorator
 */
export declare function ToNumber(): PropertyDecorator;
/**
 * Trims whitespace from string values
 * Returns non-string values unchanged
 * @returns A class-transformer decorator
 */
export declare function Trim(): PropertyDecorator;
/**
 * Transforms a value to a boolean
 * Handles string values ('true', 'false', '1', '0') and numeric values (1, 0)
 * @returns A class-transformer decorator
 */
export declare function ToBoolean(): PropertyDecorator;
