import { ColorContext, PolicyType, ProfileType } from "@driveup/shared";
import { Training } from "../training/training.model";
export declare class UserAlert {
    id: number;
    type: PolicyType;
    profileType?: ProfileType;
    profileId?: number;
    title?: string;
    message: string;
    dueDate: Date;
    context: ColorContext;
    content: string;
    training: Training;
    /************************* methods *************************/
    constructor(props?: Partial<UserAlert>);
}
