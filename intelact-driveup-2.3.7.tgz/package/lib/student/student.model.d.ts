import { Address, StatusType } from "@driveup/shared";
import { Metric } from "../metric/metric.model";
import { Training } from "../training/training.model";
export declare class Student {
    id: number;
    createdOn: Date;
    name: string;
    image: string;
    imageUrl: string;
    address: Address;
    birthday: Date;
    status: StatusType;
    phone: string;
    balance: number;
    totalPayments: number;
    trainings: Training[];
    /**
     * @deprecated Use trainings instead. This property is kept for backward compatibility and will be removed in future versions.
     */
    drivingTrainings: Training[];
    trainingId: number;
    trainingPrice: number;
    trainingStatus: StatusType;
    attended: boolean;
    metrics: Metric[];
    constructor(props?: Partial<Student>);
}
