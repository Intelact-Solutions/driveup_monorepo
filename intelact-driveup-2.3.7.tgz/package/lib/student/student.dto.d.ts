import { Address, StatusType, TrainingType } from "@driveup/shared";
export declare class SubmitStudentDto {
    name: string;
    phone: string;
    birthday: Date;
    address: Address;
}
export declare class FilterStudentDto {
    trainingTypes: TrainingType[];
    statuses: StatusType[];
    phrase: string;
    activeOnly: boolean;
    negativeBalance: boolean;
    positiveBalance: boolean;
    startDate: Date;
    endDate: Date;
    sortOrder: 'asc' | 'desc';
    sortLogic: 'student' | 'balance' | 'totalPayments' | 'registrationDate';
}
