import { StatusType } from "@driveup/shared";
export declare class CompanyInvoiceFilterDto {
    startDate: Date;
    endDate: Date;
    statuses: StatusType[];
    dueDatePassed: boolean;
    phrase: string;
    sortLogic: 'student' | 'date' | 'dueDate' | 'number' | 'amount' | 'status';
    sortOrder: 'asc' | 'desc';
}
