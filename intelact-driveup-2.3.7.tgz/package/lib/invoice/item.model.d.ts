export declare class InvoiceItem {
    id: number;
    description: string;
    amountPerUnit: number;
    quantity: number;
    constructor(props?: Partial<InvoiceItem>);
}
