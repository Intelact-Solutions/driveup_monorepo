import { ColorContext } from '@driveup/shared';
/**
 * Global item DTO.
 * In most cases, implemented in shared components.
 * It can be used in all cases where the model is not strictly defined.
 * All properties are optionally
 *
 * @param T Value model
 * @copyright Intelact Solutions Ltd.
 */
export declare class Item<T = any> {
    id?: number;
    /**
     * The name of the item for different uses.
     * In a set of items, this name must be unique
     */
    name?: string;
    /**
     * In most cases, this property is dedicated to human readable text such as label, title, etc.
     * Often, this keyword is localized and depends on the translations file
     */
    title?: string;
    /**
     * In most cases, this property is dedicated to human readable text such as description, subtitle, etc.
     * Often, this keyword is localized and depends on the translations file
     */
    subtitle?: string;
    /**
     * Value, defined by the case where it is used.
     */
    value?: T;
    /**
     * Active item status
     */
    active?: boolean;
    /**
     * Readonly indicator
     */
    readonly?: boolean;
    /**
     * Default state icon
     */
    icon?: string;
    /**
     * Optional image URL
     */
    imageUrl?: string;
    /**
     * Active state icon
     */
    iconSelected?: string;
    /**
     * Context coloring
     */
    color?: ColorContext;
    /**
     * Optional properties.
     * It could be anything.
     */
    props?: any;
    /**
     * Children items
     */
    children?: Item[];
    constructor(props?: Partial<Item>);
}
