import { Role } from "@driveup/shared";
export declare class RoleDto {
    role: Role;
}
