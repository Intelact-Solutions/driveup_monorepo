/**
 * Token interface
 *
 * @copyright Intelact Solutions Ltd.
 */
export interface IToken {
    /**
     * Token type
     * Expose token type as "Barer"
     */
    tokenType: string;
    /**
     * Access token
     * Use this token to identify auth user
     */
    accessToken: string;
    /**
     * Refresh token
     * User this token to refresh access token
     */
    refreshToken: string;
    /**
     * Access token expiry timestamp
     */
    accessTokenExpires: number;
    /**
     * Access token expiry timestamp
     */
    refreshTokenExpires: number;
}
