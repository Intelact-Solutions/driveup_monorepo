export declare class CompanyDashboardWidgetModel {
    title: string;
    amount: number;
    /**
     * The difference between the current amount and the amount of last month
     */
    performance: number;
    /************************* methods *************************/
    constructor(props?: Partial<CompanyDashboardWidgetModel>);
}
