import { Address, Coordinate, Holiday, Language, Link, StatusType } from "@driveup/shared";
import { WorkdayDefinition } from "../calendar/working";
import { Country } from "../country/country.model";
import { DrivingCategory } from "../driving/category/category.model";
import { CompanyPaymentMethod } from "../finance/payment-method.model";
import { FreeBenefit } from "../free-benefit/free-benefit.model";
import { PickupLocation } from "../geo/pickup.model";
import { Instructor } from "../instructor/instructor.model";
import { Metric } from "../metric/metric.model";
import { PricePlan } from "../priceplan/plan.model";
import { User } from "../user/user.model";
export declare class Company {
    id: number;
    uid: string;
    name: string;
    createdOn: Date;
    description: string;
    status: StatusType;
    language: Language;
    logoUrl: string;
    rating: number;
    /**
     * The obligation period set by the company.
     * If the students cancel their driving appointments outside of this period,
     * they will not be charged for the session
     * Calculated in number of hours
     */
    obligationPeriod: number;
    balance: number;
    /**
     * Promtion code from agent
     */
    promotionCode: string;
    address: Address;
    zipCode: string;
    coord: Coordinate;
    IBAN: string;
    taxId: string;
    pickupLocations: PickupLocation[];
    public: boolean;
    timezone: string;
    homepage: string;
    phone: string;
    email: string;
    socials: Link[];
    workingHours: WorkdayDefinition[];
    holidays: Holiday[];
    country: Country;
    categories: DrivingCategory[];
    activeCategories: DrivingCategory[];
    owner: User;
    myProfile: Instructor;
    /**
     * The currently active company payment method, used for processing payments
     */
    activePaymentMethod: CompanyPaymentMethod;
    /**
     * The payment method that is in pending state, waiting for verification from the provider
     */
    pendingPaymentMethod: CompanyPaymentMethod;
    currentPlan: PricePlan;
    upcomingPlan: PricePlan;
    canChangePlan: boolean;
    freeBenefits: FreeBenefit[];
    freeBenefitsAllowed: boolean;
    /**
     * @deprecated use canAddDrivingTraining and canAddCourseTraining instead
     */
    canAddTraining: boolean;
    canAddDrivingTraining: boolean;
    canAddCourseTraining: boolean;
    metrics: Metric[];
    /************************* methods *************************/
    constructor(props?: Partial<Company>);
}
