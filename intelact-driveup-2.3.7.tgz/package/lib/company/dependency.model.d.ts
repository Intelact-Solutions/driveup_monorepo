export declare class CompanyCloseProfileDependency {
    drivingTrainings: number;
    courseTrainings: number;
    constructor(props?: Partial<CompanyCloseProfileDependency>);
}
