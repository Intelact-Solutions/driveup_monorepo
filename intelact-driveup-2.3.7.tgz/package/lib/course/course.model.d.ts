import { CourseType, StatusType } from "@driveup/shared";
import { Appointment } from "../calendar/appointment";
import { DrivingCategory } from "../driving/category/category.model";
import { Instructor } from "../instructor/instructor.model";
import { CoursePart } from "./part.model";
export declare class Course {
    id: number;
    title: string;
    description: string;
    location: string;
    price: number;
    /**
     * Wether or not the course is visible to the public
     */
    public: boolean;
    status: StatusType;
    startDate: Date;
    endDate: Date;
    courseType: CourseType;
    /**
     * Maximum number of students for each appointment
     */
    maxStudents: number;
    activeStudents: number;
    remainingSeats: number;
    totalParts: number;
    remainingParts: number;
    partsWithNoAppointments: CoursePart[];
    partsWithNoSeats: CoursePart[];
    appointmentsInHolidays: Appointment[];
    drivingCategory: DrivingCategory;
    /************************* Student course training info *************************/
    lastStudentAppointment: Date;
    canceledAppointments: number;
    notFinishableStudents: number;
    /************************* relations *************************/
    /**
     * In charge instructor
     */
    instructor: Instructor;
    /************************* methods *************************/
    constructor(props?: Partial<Course>);
}
