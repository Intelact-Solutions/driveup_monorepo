import { CourseType, StatusType, WeekDay } from "@driveup/shared";
export declare class CourseCreateDto {
    courseType: CourseType;
}
export declare class CourseMaxStudentsDto {
    maxStudents: number;
}
export declare class CoursePartDurationDto {
    duration: number;
}
export declare class CourseDefinitionCreateDto {
    startDate: Date;
    duration: number;
    repetition: boolean;
    instructorId: number;
    weekdays: WeekDay[];
    endDate: Date;
    /************************* methods *************************/
    constructor(props?: Partial<CourseDefinitionCreateDto>);
}
export declare class CourseDefinitionUpdateDto {
    date: Date;
    update: Date;
    instructorId: number;
    duration: number;
    endDate: Date;
    repetition: boolean;
    weekdays: WeekDay[];
    /**
     * Update this one, or all upcoming appointments
     */
    limit: 'self' | 'upcoming';
    /************************* methods *************************/
    constructor(props?: Partial<CourseDefinitionUpdateDto>);
}
export declare class CourseAppointmentFilterDto {
    startDate: Date;
    endDate: Date;
    courses: number[];
    instructors: number[];
    parts: number[];
}
export declare class CourseFilterDto {
    phrase: string;
    statuses: StatusType[];
    instructors: number[];
}
