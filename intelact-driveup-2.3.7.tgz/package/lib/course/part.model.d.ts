import { Instructor } from "../instructor/instructor.model";
import { Appointment } from "../calendar/appointment";
export declare class CoursePart {
    id: number;
    number: number;
    instructor: Instructor;
    title: string;
    description: string;
    startDate: Date;
    endDate: Date;
    duration: number;
    sort: number;
    canceled: boolean;
    remainingSeats: number;
    /************************* Flexible course info *************************/
    hasUpcomingAppointments: boolean;
    /**
     * Dates on wihch the student has registered for the part
     */
    registeredAppointments: Appointment[];
    /************************* methods *************************/
    constructor(props?: Partial<CoursePart>);
}
