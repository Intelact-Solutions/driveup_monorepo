import { WeekDay } from '@driveup/shared';
import { Instructor } from '../instructor/instructor.model';
export declare class CoursePartDefinition {
    id: number;
    partId: number;
    startDate: Date;
    endDate: Date;
    defaultInstructor: Instructor;
    duration: number;
    repetition: boolean;
    weekdays: WeekDay[];
    updatedAppointmentsInFuture: number;
    /************************* methods *************************/
    constructor(props?: Partial<CoursePartDefinition>);
}
