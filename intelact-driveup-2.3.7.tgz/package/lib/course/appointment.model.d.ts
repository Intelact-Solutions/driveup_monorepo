import { Appointment } from "../calendar/appointment";
import { CourseType } from "@driveup/shared";
import { Student } from "../student/student.model";
/**
 * Appointments that are defined in the calendar for a course by the company
 */
export declare class CourseAppointment extends Appointment {
    courseType: CourseType;
    students: Student[];
    totalAttended: number;
    totalAbsent: number;
    /************************* methods *************************/
    constructor(props?: Partial<CourseAppointment>);
}
