import { Coordinate, Language, ProfileType, StatusType } from "@driveup/shared";
import { Instructor } from "../instructor/instructor.model";
import { Company } from "../company/company.model";
import { Country } from "../country/country.model";
import { Student } from "../student/student.model";
import { Metric } from "../metric/metric.model";
import { Agent } from "../agent/agent.model";
import { UserAlert } from "../alert/alert.model";
/**
 * Implemented for all kind of users (student, instructor, company user or agent).
 * Depends on app sessions (public, mobile, admin, console).
 * Some of properties can have different validaition rules.
 */
export declare class User {
    id: number;
    uid: string;
    language: Language;
    status: StatusType;
    /******************** Personal Data ********************/
    name: string;
    phone: string;
    image: string;
    imageUrl: string;
    email: string;
    birthday: Date;
    address: string;
    zipCode: string;
    location: string;
    coord: Coordinate;
    timezone: string;
    /************************* alerts *************************/
    alerts: UserAlert[];
    /************************** activity ***************************/
    lastActivity: Date;
    overdatedActivity: boolean;
    /************************* profiles **************************/
    selectedProfile: ProfileType;
    student: Student;
    agent: Agent;
    instructor: Instructor;
    companies: Company[];
    country: Country;
    company: Company;
    createdOn: Date;
    metrics: Metric[];
    /************************* methods *************************/
    constructor(props?: Partial<User>);
    static toInstance(data: any): User[];
    isActive(): boolean;
}
