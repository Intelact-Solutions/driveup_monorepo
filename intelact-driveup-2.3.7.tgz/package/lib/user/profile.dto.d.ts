import { Language, ProfileType } from "@driveup/shared";
export declare class CreateProfileDto {
    type: ProfileType;
    language: Language;
}
export declare class ChangeProfileDto {
    type: ProfileType;
    id: number;
}
export declare class CloseProfileDto {
    otp: string;
}
