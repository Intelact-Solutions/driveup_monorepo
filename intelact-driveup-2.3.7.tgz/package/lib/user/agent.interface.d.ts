import { Language } from "@driveup/shared";
export interface IUserAgent {
    countryCode: string;
    language: Language;
    languages: Language[];
}
